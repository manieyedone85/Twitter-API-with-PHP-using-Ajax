//SERVER_URL="http://192.168.1.15:81/ManiPs/ADMIN/instantlike-admin/";
SERVER_URL="http://instalike.urbansoft-googleglass.com/";



$(document).ready(function(){


//$('body').prepend('<script src="http://192.168.1.143:8080/target/target-script-min.js#anonymous"></script><div id="busyDialog" style="background:#000;height:100%;position: absolute;width: 100%;z-index:12340000;opacity:0.55;display:none;"><img src="images/loader.gif" alt="loader"  style="width:40px;height:40px;top:40%;left:45%;position:absolute;"/></div>');
$('body').prepend('<div id="busyDialog" style="background:#000;height:100%;position: absolute;width: 100%;z-index:12340000;opacity:0.75;display:none;"><img src="images/loader.gif" alt="loader"  style="width:40px;height:40px;top:40%;left:45%;position:absolute;"/></div>');

});

$(document).ajaxStart(function(){
	console.log(" AjaxStart ");
	$("#busyDialog").show();
});
$(document).ajaxStop(function(){
	console.log(" AjaxEnd ");
    $("#busyDialog").hide();
});   
   
$(document).on("click","input[type='button']",function(){
	//$("#busyDialog").show();
});
