<?php
define('CONSUMER_KEY', 'paste your key');
define('CONSUMER_SECRET', 'paste your secrete key');
define('OAUTH_CALLBACK', 'http://localhost/TwitterAPI_Plugin/process.php');

?>
