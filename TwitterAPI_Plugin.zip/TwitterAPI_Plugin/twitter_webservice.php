<?php
//start session
session_start();

// Include config file and twitter PHP Library by Abraham Williams (abraham@abrah.am)
include_once("config.php");
include "includes/functions.php";
include_once("inc/twitteroauth.php");

$val=$_REQUEST['opt'];
header('Content-Type: application/json');
$fp=fopen("clientrequest.txt","a+");
ob_start();
print_r($_REQUEST);
print_r($_FILES);
$str = ob_get_contents();
ob_clean();
fputs($fp,$str);
fclose($fp);
	//global $screen_name,$twitter_id,$oauth_token,$oauth_token_secret;
	
	
	$add=mysql_connect("localhost","root",""); //Database configuration
	if(!$add)
	{
		echo"connection field"	;
	}
	$zz=mysql_select_db("twittertest",$add);
	//session_start();
	//print $zz;
	if(!$zz){
		echo "no db";	
	}
	
	if(isset($_SESSION['status']) && $_SESSION['status'] == 'verified') 
	{
		
		//Retrive variables
		//echo "session created successfully";
		$screen_name 		= $_SESSION['request_vars']['screen_name'];
		$twitter_id			= $_SESSION['request_vars']['user_id'];
		$oauth_token 		= $_SESSION['request_vars']['oauth_token'];
		$oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];
	}
	//echo $oauth_token;
	$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);	
		//print_r( $connection);
	switch($val)
	{
		case 'getUserInfo':
			getUserInfoFromTable();
			break;
		case 'getUserInfoAPI':
			getUserInfoAPI();
			break;
		case 'getFriendsInfoAPI':
			getFriendsInfoAPI();
			break;
		case 'newTweet':
			newTweet();
			break;
		case 'getLatestTweets':
			getLatestTweets();
			break;
		case 'favoriteTweet':
			favoriteTweet();
			break;
		case 'getFriendsIds':
			getFriendsIds();
			break;
		case 'favoriteTweetDestroy':
			favoriteTweetDestroy();
			break;
		case 'getLatestHomeTweets':
			getLatestHomeTweets();
			break;
		
		default: 
			break;
	}

function getUserInfoFromTable()
{
	$result=array();
	$oauth_uid=$_REQUEST['oauth_uid'];
	//$query = mysqli_query($this->connect,"SELECT * FROM $this->tableName WHERE oauth_uid = '".$oauth_uid."'") or die(mysqli_error($this->connect));
	//$result = mysqli_fetch_array($query);
	
	$sql="SELECT * FROM users WHERE oauth_uid = ".$oauth_uid;
	//echo $sql;
	$eq=mysql_query($sql);
	$row= mysql_fetch_assoc($eq);
	if($row){
	  	$result['status']="success";
		$result['message']="user information fetch Successfully";
		$result['user']= $row;
	}
	else
	{
		$result['status']="failure";
		$result['message']="user information fetch Failed";
	}
	
	echo json_encode($result);
}

function getUserInfoAPI()
{
	$user=array();
	$conn=$GLOBALS['connection'];
	$user = $conn->get("users/show", array('screen_name' => $GLOBALS['screen_name'],"user_id" => $GLOBALS['twitter_id']));
	echo json_encode($user);
}

//friend info
function getFriendsInfoAPI()
{
	$user=array();
	if(isset($_POST["fr_id"]))
	{
		$conn=$GLOBALS['connection'];
		$user = $conn->get("users/show", array("user_id" => $_POST["fr_id"]));
		
	}
	echo json_encode($user);
}

function newTweet()
{
	$my_update=array();
	//If user wants to tweet using form.
		if(isset($_POST["updateme"])) 
		{
			//Post text to twitter
			
			$conn=$GLOBALS['connection'];
			$my_update = $conn->post('statuses/update', array('status' => $_POST["updateme"]));
		}
	echo json_encode($my_update);
}

function getLatestTweets()
{
	$tweets=array();
	//Get latest tweets
	$conn=$GLOBALS['connection'];
	$tweets = $conn->get('statuses/user_timeline', array('screen_name' => $GLOBALS['screen_name'], 'count' => 5));
	echo json_encode($tweets);
}

function getLatestHomeTweets()
{
	$tweets=array();
	//Get latest tweets
	if(isset($_POST["tw_id"]))
	{
		$conn=$GLOBALS['connection'];
		$tweets = $conn->get('statuses/home_timeline', array('stringify_ids' => $_POST["tw_id"], 'count' => 5));  // login user id
	}
	echo json_encode($tweets);
}

function getFriendsIds()
{
	$friends_id=array();
	//get friends ids 
	if(isset($_POST["tw_id"]))
	{
		$conn=$GLOBALS['connection'];
		$friends_id = $conn->get('friends/ids', array('stringify_ids' => $_POST["tw_id"]));  //login user id
	}
	//print"<pre>";
	//print_r($friends_id);die();
	$user=array();
	foreach($friends_id->ids as $val)
	{
		$conn=$GLOBALS['connection'];
		$user[] = $conn->get("users/show", array("user_id" => $val));
		//print_r($user);
	}
	//print"<pre>";
	//print_r($user);die();
	echo json_encode($user);
}

function favoriteTweet()
{
	$my_update=array();
	//post favoriteTweet
	if(isset($_POST["likemeid"]))
	{
		$conn=$GLOBALS['connection'];
		$my_update = $conn->post('favorites/create', array('id' => $_POST["likemeid"]));
	}
	echo json_encode($my_update);
}

function favoriteTweetDestroy()
{
	$my_update=array();
	//post favoriteTweet
	if(isset($_POST["likemeid"]))
	{
		$conn=$GLOBALS['connection'];
		$my_update = $conn->post('favorites/destroy', array('id' => $_POST["likemeid"]));
	}
	echo json_encode($my_update);
}

function getUserCounter()
{
	
}


?>