<?php
//start session
session_start();

// Include config file and twitter PHP Library by Abraham Williams (abraham@abrah.am)
include_once("config.php");
include "includes/functions.php";
include_once("inc/twitteroauth.php");
?>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Twitter API Example</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.10.2.js" ></script>
	<script src="js/jquery.validate.js" ></script>
	<script src="js/bootstrap.js" ></script>
    
</head>
<body>
<?php
	if(isset($_SESSION['status']) && $_SESSION['status'] == 'verified') 
	{
		
		//Retrive variables
		$screen_name 		= $_SESSION['request_vars']['screen_name'];
		$twitter_id			= $_SESSION['request_vars']['user_id'];
		$oauth_token 		= $_SESSION['request_vars']['oauth_token'];
		$oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];
		echo '<div class="welcome_txt">Welcome <strong>'.$screen_name.'</strong> (Twitter ID : '.$twitter_id.'). <strong> TweetCount: <span class="tweetscount"></span></strong> <strong> FriendsCount: <span class="following"></span></strong><strong> Followers: <span class="followers"></span></strong> <img src="images/profile.png" class="proimg"><a class="logout pull-right" href="logout.php?logout">Logout!</a></div>';
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);
	}else{
		//Display login button
		echo '<a href="process.php"><img src="images/sign-in-with-twitter.png" width="151" height="24" border="0" /></a>';
	}
?>
	
	<div class="tweet_box">
		<form method="" action="" id="form_new_post">
		
			<textarea class="updateme" name="updateme" cols="60" rows="3" id="updateme" placeholder="Type your tweets here" ></textarea>
			<input type="button" value="Tweet" class="postnewtweet"/>
			
		</form>
	</div>
	<div class="tweet_list"><strong>Latest Tweets : </strong><button class="divclose" id="cmytweets" data_first=1 data_close=1>show</button>
		<ul id="mytweets">
			
		</ul>
	</div>
	
	<div class="tweet_list"><strong>Home Tweets : </strong><button class="divclose" id="chometweets" data_first=1 data_close=1>show</button>
		<ul id="hometweets">
			
		</ul>
	</div>

	
	<div class="tweet_list">
	<div style="height: 25px;">
		<strong>My Friends Ids : </strong><button class="divclose" id="cfriends_ids" data_first=1 data_close=1>show</button>
	</div>
	
		<ul id="friends_ids">
		</ul>
	</div>
<script>
var twitter_id="";

$(document).ready(function(){
	twitter_id=<?php echo $twitter_id;?>;
	
	//profile image change
	$.ajax({
		url:"twitter_webservice.php",
		type:"post",
		data:{oauth_uid:twitter_id,"opt":"getUserInfo"}
	}).done(function(data){
		//console.log(data);
		if(data.status=="success")
			$('.proimg').attr("src",data.user.picture);
	
	});

	/*//get latest my tweets
	$.ajax({
		url:"twitter_webservice.php",
		type:"post",
		data:{"opt":"getLatestTweets"}
	}).done(function(data){
		//console.log(data);
		result="";
		for(i=0;i<data.length;i++)
		{
			result+='<li>'+data[i].text+'<strong>like count:<span class="likecount">'+data[i].favorite_count+'</span></strong>';
			if(!data[i].favorited)
				result+='<button class="favorite_me" value="LikeMe" data_id="'+data[i].id_str+'" data_flag=0>LikeMe</button>';
			else
				result+='<button class="favorite_me" value="Liked" data_id="'+data[i].id_str+'" data_flag=1>Liked</button>';
			result+='<br><i>-- '+data[i].created_at+'</i></li>';
		}
		$('#mytweets').html(result);
	});
	*/
	
	//get user info
	$.ajax({
		url:"twitter_webservice.php",
		type:"post",
		data:{"opt":"getUserInfoAPI"}
	}).done(function(data){
		//console.log(data);
		$('.tweetscount').html(data.statuses_count);
		$('.following').html(data.friends_count);
		$('.followers').html(data.followers_count);
	});
	
	/*//get friends info
	$(document).on('click','.fr_link',function(){
		$.ajax({
			url:"twitter_webservice.php",
			type:"post",
			data:{"opt":"getUserInfoAPI"}
		}).done(function(data){
			console.log(data);
			$('.tweetscount').html(data.statuses_count);
			$('.following').html(data.friends_count);
			$('.followers').html(data.followers_count);
		});
	});
	*/
	
	/*//get latest home tweets
	$.ajax({
		url:"twitter_webservice.php",
		type:"post",
		data:{tw_id:twitter_id,"opt":"getLatestHomeTweets"}
	}).done(function(data){
		//console.log(data);
		result="";
		for(i=0;i<data.length;i++)
		{
			result+='<li>'+data[i].text+'<strong>like count:<span class="likecount">'+data[i].favorite_count+'</span></strong>';
			if(!data[i].favorited)
				result+='<button class="favorite_me" value="LikeMe" data_id="'+data[i].id_str+'" data_flag=0>LikeMe</button>';
			else
				result+='<button class="favorite_me" value="Liked" data_id="'+data[i].id_str+'" data_flag=1>Liked</button>';
			result+='<br><i>-- '+data[i].created_at+'</i></li>';
		}
		$('#hometweets').html(result);
	});*/
	
	
	
	/*//show friends image getFriendsInfoAPI
	$(document).on('click','.my_friend_id',function(){
		friends_id=$(this).attr("data_id");
		$.ajax({
			url:"twitter_webservice.php",
			type:"post",
			data:{fr_id:friends_id,"opt":"getFriendsInfoAPI"}
		}).done(function(data){
			console.log(data);
			
		});
	
	});*/
	
	$('#form_new_post').validate({
	rules:{
		updateme:"required"
	},
	errorPlacement: function(error,element){return true;}
			 
	});
	
	// post new tweet
	$(document).on('click','.postnewtweet',function(e){
		e.preventDefault();
		if($('#form_new_post').valid()){	
			tupdateme=$('#updateme').val();
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{updateme:tupdateme,"opt":"newTweet"}
			}).done(function(data){
				console.log(data);
				$('#updateme').val("");
				result="";
				//result+='<li>first tweet <strong>like count:<span class="likecount">0</span></strong>';
				//result+='<button type="submit" value="LikeMe" data_id="" data_flag=0>LikwMe</button></li>';
			
			});
		}
	});
	
	//like api call   
	$(document).on('click','.favorite_me',function(){
		fav_id=$(this).attr("data_id");
		index=$('.favorite_me').index(this);
		fav_flag=$(this).attr("data_flag");
		if(fav_flag==0)
		{
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{likemeid:fav_id,"opt":"favoriteTweet"}
			}).done(function(data){
				if(data.favorited==true){
					$('.favorite_me').eq(index).attr("data_flag",1);
					$('.favorite_me').eq(index).html("Liked");
					lcount=$('.likecount').eq(index).html();
					lc=parseInt(lcount)+1;
					$('.likecount').eq(index).html(lc);
				}
			});
		}else{
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{likemeid:fav_id,"opt":"favoriteTweetDestroy"}
			}).done(function(data){
				if(data.favorited==false){
					$('.favorite_me').eq(index).attr("data_flag",0);
					$('.favorite_me').eq(index).html("LikeMe");
					lcount=$('.likecount').eq(index).html();
					lc=parseInt(lcount)-1;
					$('.likecount').eq(index).html(lc);
				}
			});
		
		}
	});
	
	//lattest home tweet close bt
	$(document).on('click','#chometweets',function(){
		index=$('#chometweets').index(this);
		status=$(this).attr('data_close');
		first_flag=$(this).attr('data_first');
		if(first_flag==1)
		{
			//get latest home tweets
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{tw_id:twitter_id,"opt":"getLatestHomeTweets"}
			}).done(function(data){
				//console.log(data);
				result="";
				for(i=0;i<data.length;i++)
				{
					result+='<li>'+data[i].text+'<strong>like count:<span class="likecount">'+data[i].favorite_count+'</span></strong>';
					if(!data[i].favorited)
						result+='<button class="favorite_me" value="LikeMe" data_id="'+data[i].id_str+'" data_flag=0>LikeMe</button>';
					else
						result+='<button class="favorite_me" value="Liked" data_id="'+data[i].id_str+'" data_flag=1>Liked</button>';
					result+='<br><i>-- '+data[i].created_at+'</i></li>';
				}
				$('#hometweets').html(result);
				$('#hometweets').show();
				$('#chometweets').eq(index).attr('data_first',0);
				$('#chometweets').eq(index).attr('data_close',0);
				$('#chometweets').eq(index).html('close');
			});
		
		}
		
		if(status==1)
		{
			$('#hometweets').show();
			$('#chometweets').eq(index).attr('data_close',0);
			$('#chometweets').eq(index).html('close');
			
		}
		else
		{
			$('#hometweets').hide();
			$('#chometweets').eq(index).attr('data_close',1);
			$('#chometweets').eq(index).html('show');
		}
	
	});
	
	//my tweet for close bt
	$(document).on('click','#cmytweets',function(){
		index=$('#cmytweets').index(this);
		//alert($(this));
		status=$(this).attr('data_close');
		first_flag=$(this).attr('data_first');
		if(first_flag==1)
		{
			//get latest my tweets
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{"opt":"getLatestTweets"}
			}).done(function(data){
				//console.log(data);
				result="";
				for(i=0;i<data.length;i++)
				{
					result+='<li>'+data[i].text+'<strong>like count:<span class="likecount">'+data[i].favorite_count+'</span></strong>';
					if(!data[i].favorited)
						result+='<button class="favorite_me" value="LikeMe" data_id="'+data[i].id_str+'" data_flag=0>LikeMe</button>';
					else
						result+='<button class="favorite_me" value="Liked" data_id="'+data[i].id_str+'" data_flag=1>Liked</button>';
					result+='<br><i>-- '+data[i].created_at+'</i></li>';
				}
				$('#mytweets').html(result);
			});
			$('#mytweets').show();
			$('#cmytweets').eq(index).attr('data_first',0);
			$('#cmytweets').eq(index).attr('data_close',0);
			$('#cmytweets').eq(index).html('close');
		}
		
		if(status==1)
		{
			$('#mytweets').show();
			$('#cmytweets').eq(index).attr('data_close',0);
			$('#cmytweets').eq(index).html('close');
		}
		else
		{
			$('#mytweets').hide();
			$('#cmytweets').eq(index).attr('data_close',1);
			$('#cmytweets').eq(index).html('show');
		}
	
	});
	
	
	//friends id list for close bt
	$(document).on('click','#cfriends_ids',function(){
		index=$('#cfriends_ids').index(this);
		
		status=$(this).attr('data_close');
		if(status==1)
		{
			//get my friends id
			$.ajax({
				url:"twitter_webservice.php",
				type:"post",
				data:{tw_id:twitter_id,"opt":"getFriendsIds"}
			}).done(function(data){
				//console.log(data);
				result="";
				for(i=0;i<data.length;i++)
				{
					//result+='<li class="friendslist">'+data.ids[i]+'<a href="javascript:void(0);" class="my_friend_id" data_id="'+data.ids[i]+'">Show Image</a><img src="images/profile.png" class="proimg1"></li>';
					result+='<li class="friendslist">'+data[i].name+'<img src="'+data[i].profile_image_url+'" class="proimg1"></li>';
				}
				$('#friends_ids').html(result);
				$('#friends_ids').show();
				$('#cfriends_ids').eq(index).attr('data_close',0);
				$('#cfriends_ids').eq(index).html('close');
			});
			
		}
		else
		{
			$('#friends_ids').hide();
			$('#cfriends_ids').eq(index).attr('data_close',1);
			$('#cfriends_ids').eq(index).html('show');
		}
	
	});

});
</script>
<style type="text/css">
	.tweet_box textarea .error
	{
		border:1px solid red;
		border-radius:5px;
	}

</style>
</body>

</html>